﻿using System;
using System.Collections;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Botoes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string saida = "";

            for (var i = 0; i < 20; i++)
            {
                string input = Interaction.InputBox("Digite o número", "Entrada de dados");

                if (int.TryParse(input, out vetor[i]))
                {
                    saida = vetor[i] + "\n" + saida;
                }
                else
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }

            MessageBox.Show(saida, "Números Invertidos");
        }

        private void btnExe3_Click(object sender, EventArgs e)
        {
            int numAlunos = 20;
            int numNotas = 3;
            double[,] notas = new double[numAlunos, numNotas];
            string saida = "";

            for (int i = 0; i < numAlunos; i++)
            {
                for (int j = 0; j < numNotas; j++)
                {
                    string input = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1} (0 a 10)", "Entrada de Dados");

                    if (double.TryParse(input, out double nota) && nota >= 0 && nota <= 10)
                    {
                        notas[i, j] = nota;
                    }
                    else
                    {
                        MessageBox.Show("Nota inválida! Digite um valor entre 0 e 10.");
                        j--;
                    }
                }

                double media = (notas[i, 0] + notas[i, 1] + notas[i, 2]) / numNotas;
                saida += "Aluno " + (i + 1) + ": média: " + media.ToString("F1") + "\n";
            }

            MessageBox.Show(saida, "Médias dos Alunos");
        }

        private void btnExe2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            alunos.Remove("Otávio");

            string mensagem = "Lista de alunos:\n";
            foreach (string aluno in alunos)
            {
                mensagem += aluno + "\n";
            }
            MessageBox.Show(mensagem, "Exercício 2");
        }

        private void btnExe4_Click_1(object sender, EventArgs e)
        {
            frmEx4 frmEx4 = new frmEx4();
            frmEx4.ShowDialog();
        }

        private void btnExe5_Click(object sender, EventArgs e)
        {
            frmEx5 frmEx5 = new frmEx5();
            frmEx5.ShowDialog();
        }
    }

    public partial class FormNomes : Form
    {
        private ListBox listBoxNomes;

        public FormNomes()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            listBoxNomes = new ListBox();
            listBoxNomes.Dock = DockStyle.Fill;
            Controls.Add(listBoxNomes);
            Text = "FormNomes";
            ClientSize = new System.Drawing.Size(400, 300);
        }

        public void CarregarNomes()
        {
            string[] nomes = new string[10];

            for (int i = 0; i < 10; i++)
            {
                string nome = Interaction.InputBox("Digite o nome completo da pessoa " + (i + 1) + ":", "Entrada de Nomes");
                nomes[i] = nome;
                listBoxNomes.Items.Add("Nome: " + nome + " - Comprimento (sem espaços): " + nome.Replace(" ", "").Length);
            }
        }
    }
}
