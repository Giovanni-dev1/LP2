﻿namespace Botoes
{
    partial class frmEx5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEx5 = new System.Windows.Forms.Button();
            this.lbox3 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnEx5
            // 
            this.btnEx5.Location = new System.Drawing.Point(275, 155);
            this.btnEx5.Name = "btnEx5";
            this.btnEx5.Size = new System.Drawing.Size(75, 23);
            this.btnEx5.TabIndex = 0;
            this.btnEx5.Text = "Executar";
            this.btnEx5.UseVisualStyleBackColor = true;
            this.btnEx5.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbox3
            // 
            this.lbox3.FormattingEnabled = true;
            this.lbox3.Location = new System.Drawing.Point(442, 75);
            this.lbox3.Name = "lbox3";
            this.lbox3.Size = new System.Drawing.Size(297, 342);
            this.lbox3.TabIndex = 1;
            // 
            // frmEx5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbox3);
            this.Controls.Add(this.btnEx5);
            this.Name = "frmEx5";
            this.Text = "frmEx5";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEx5;
        private System.Windows.Forms.ListBox lbox3;
    }
}