﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Botoes
{
    public partial class frmEx5 : Form
    {
        public frmEx5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int ultimoDigitoRA = 5; // Ajuste para o último dígito do seu RA
            int N = (ultimoDigitoRA == 0) ? 2 : ultimoDigitoRA;
            char[] gabarito = { 'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };
            char[,] respostasAlunos = new char[N, 10];

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    string input = Interaction.InputBox($"Digite a resposta da questão {j + 1} do aluno {i + 1} (A, B, C, D, E):", "Entrada de Respostas");
                    if (!string.IsNullOrEmpty(input) && input.Length == 1 && "ABCDE".Contains(input.ToUpper()))
                        respostasAlunos[i, j] = char.ToUpper(input[0]);
                    else
                    {
                        MessageBox.Show("Resposta inválida! Digite apenas A, B, C, D ou E.");
                        j--;
                    }
                }
            }

            lbox3.Items.Clear();
            for (int i = 0; i < N; i++)
            {
                int acertos = 0;
                for (int j = 0; j < 10; j++)
                {
                    if (respostasAlunos[i, j] == gabarito[j])
                    {
                        acertos++;
                        lbox3.Items.Add($"Aluno {i + 1} acertou questão {j + 1} e escolheu {respostasAlunos[i, j]}.");
                    }
                    else
                    {
                        lbox3.Items.Add($"Aluno {i + 1} errou questão {j + 1} e escolheu {respostasAlunos[i, j]}.");
                    }
                }
                
            }

           
        }
    }
}