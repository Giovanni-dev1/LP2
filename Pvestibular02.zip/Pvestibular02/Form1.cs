﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvestibular02
{
    public partial class Form1 : Form
    {
        
        private ListBox listBoxResultados;
        private Button calcularButton;
        private Button limparButton;
        private int[,] matrizAlunos = new int[2, 5]; 

        public Form1()
        {
            InitializeComponent();

            listBoxResultados = new ListBox()
            {
                Location = new System.Drawing.Point(10, 10),
                Size = new System.Drawing.Size(500, 200)
            };

            
            calcularButton = new Button()
            {
                Text = "Calcular e Exibir Resultados",
                Location = new System.Drawing.Point(10, 220),
                Size = new System.Drawing.Size(250, 40)
            };
            calcularButton.Click += calcularButton_Click;

           
            limparButton = new Button()
            {
                Text = "Limpar Resultados",
                Location = new System.Drawing.Point(270, 220),
                Size = new System.Drawing.Size(250, 40)
            };
            limparButton.Click += limparButton_Click;

            
            Controls.Add(listBoxResultados);
            Controls.Add(calcularButton);
            Controls.Add(limparButton);
        }

        
        private void calcularButton_Click(object sender, EventArgs e)
        {
            listBoxResultados.Items.Clear(); 
            int totalGeral = 0;

            
            for (int i = 0; i < 2; i++) 
            {
                for (int j = 0; j < 5; j++) 
                {
                    string input = Interaction.InputBox($"Digite o número de alunos do Curso {i + 1} no Ano {j + 1}:", "Entrada de Dados");

                    // Validar a entrada e armazenar na matriz
                    if (int.TryParse(input, out int alunos) && alunos >= 0)
                    {
                        matrizAlunos[i, j] = alunos;
                    }
                    else
                    {
                        MessageBox.Show("Por favor, insira um número inteiro positivo.");
                        j--; 
                    }
                }
            }

            
            for (int i = 0; i < 2; i++)
            {
                int totalCurso = 0;
                for (int j = 0; j < 5; j++)
                {
                    totalCurso += matrizAlunos[i, j];
                }
                listBoxResultados.Items.Add($"Total de alunos no Curso {i + 1}: {totalCurso}");
                totalGeral += totalCurso;
            }

            
            for (int j = 0; j < 5; j++)
            {
                int totalAno = 0;
                for (int i = 0; i < 2; i++)
                {
                    totalAno += matrizAlunos[i, j];
                }
                listBoxResultados.Items.Add($"Total de alunos no Ano {j + 1}: {totalAno}");
            }

            // Exibir o total geral de alunos
            listBoxResultados.Items.Add($"Total Geral de alunos: {totalGeral}");
        }

        // Evento para o botão de limpar
        private void limparButton_Click(object sender, EventArgs e)
        {
            listBoxResultados.Items.Clear(); // Limpar o ListBox
        }
    }

}