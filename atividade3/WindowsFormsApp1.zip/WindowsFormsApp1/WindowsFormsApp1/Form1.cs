﻿using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        double Numero1, Numero2, Resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxAltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            
            }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(mskbxAltura.Text, out Numero2)) || (Numero2 <= 0))
            {
                MessageBox.Show("Altura Inválido");


                Focus();

            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double peso = Convert.ToDouble(mskbxPeso.Text);
            double altura = Convert.ToDouble(mskbxAltura.Text);

            double imc = peso / (altura * altura);

            txtImc.Text = imc.ToString("F2");
            txtImc.Visible = true;
                
            string classificacao = String.Empty;
            imc = Math.Round(imc, 1);
             if (imc<=16.9)
                classificacao = "Muito abaixo do peso";
             if ( imc <= 18.4)
                classificacao = "Abaixo do peso";
            else if ( imc <= 24.9)
                classificacao = "Peso normal";
            else if ( imc <= 29.9)
                classificacao = "Acima do peso";
            else if ( imc <= 34.9)
                classificacao = "Obesidade Grau I";
            else if  (imc <= 39.9)
                classificacao = "Obesidade Grau II";
            else if (imc > 40)
                classificacao = "Obesidade Grau III";

             lblClassificacao.Text = classificacao;
           
        }

        private void txtImc_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            txtImc.Clear();

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(mskbxPeso.Text,out Numero1)) || (Numero1<=0))
            {
                MessageBox.Show("Peso Inválido");


                    mskbxPeso.Focus(); 
                }
            }
        }
    }

